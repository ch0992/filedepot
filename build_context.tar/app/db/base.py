"""
app/db/base.py
SQLAlchemy Base 클래스 정의 (placeholder)
"""

from sqlalchemy.orm import declarative_base

Base = declarative_base()
