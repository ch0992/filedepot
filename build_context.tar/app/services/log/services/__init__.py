# app/log/services: 로그 서비스 비즈니스 로직 패키지
