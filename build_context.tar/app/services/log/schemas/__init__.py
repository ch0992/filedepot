# app/log/schemas: 로그 서비스용 Pydantic 스키마 패키지
