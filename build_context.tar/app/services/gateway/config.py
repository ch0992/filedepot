"""
app/gateway/config.py
게이트웨이 서비스 전용 설정 (placeholder)
"""
# 예시 환경설정
JWT_SECRET = "your-secret-key"
