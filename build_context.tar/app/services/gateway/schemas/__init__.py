# app/gateway/schemas: 게이트웨이 서비스용 Pydantic 스키마 패키지
