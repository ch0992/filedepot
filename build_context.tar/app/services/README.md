# app/services/

각 마이크로서비스(file, data, log, gateway)는 이 디렉토리 하위에 그룹화되어 있습니다.

- 예시: app/services/file, app/services/data, ...
- 공통 모듈은 app/core, app/db 등에서 import
