# app/data/schemas: 데이터 서비스용 Pydantic 스키마 패키지
