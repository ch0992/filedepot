"""
app/shared/utils.py
공통 유틸리티 함수 (placeholder)
"""
def get_project_name():
    return "filedepot"
