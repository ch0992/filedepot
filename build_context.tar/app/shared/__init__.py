# app/shared: 공통 유틸리티, Enum, Pydantic 모델 등 패키지
