# infra/README.md

- docker-compose, Kind 클러스터 등 인프라 구성 파일 위치
- 실제 서비스/DB/미들웨어 컨테이너 정의 및 클러스터 세팅은 이곳에서 관리합니다.
